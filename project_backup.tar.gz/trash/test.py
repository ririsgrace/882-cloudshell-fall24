from main import task
task(None)
